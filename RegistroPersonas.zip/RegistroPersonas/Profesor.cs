﻿public class Profesor : Persona
{
    public string Materia { get; set; }

    public override string MostrarDatos()
    {
        return $"Profesor: {Nombre} {Apellido}, Edad: {Edad}, Materia: {Materia}";
    }
}