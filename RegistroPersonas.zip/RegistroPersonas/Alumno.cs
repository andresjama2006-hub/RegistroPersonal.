﻿public class Alumno : Persona
{
    public string Carrera { get; set; }

    public override string MostrarDatos()
    {
        return $"Alumno: {Nombre} {Apellido}, Edad: {Edad}, Carrera: {Carrera}";
    }
}