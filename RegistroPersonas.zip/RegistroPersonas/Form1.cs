﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace RegistroPersonas
{
    public partial class Form1 : Form
    {
        // Lista global para almacenar personas
        List<Persona> personas = new List<Persona>();

        public Form1()
        {
            InitializeComponent();
        }

        // Evento que se ejecuta al cargar el formulario
        private void Form1_Load(object sender, EventArgs e)
        {
            cboTipo.Items.Add("Alumno");
            cboTipo.Items.Add("Profesor");
            cboTipo.SelectedIndex = 0;
            lblExtra.Text = "Carrera"; // Texto inicial del campo extra
        }

        // Evento que cambia la etiqueta según el tipo seleccionado
        private void cboTipo_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblExtra.Text = cboTipo.SelectedItem.ToString() == "Alumno" ? "Carrera" : "Materia";
        }

        // Evento del botón Agregar
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            // Validación básica
            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtApellido.Text) ||
                string.IsNullOrWhiteSpace(txtEdad.Text) ||
                string.IsNullOrWhiteSpace(txtExtra.Text))
            {
                MessageBox.Show("Por favor, completa todos los campos.");
                return;
            }

            // Validar que Edad sea un número entero
            if (!int.TryParse(txtEdad.Text, out int edad))
            {
                MessageBox.Show("Edad debe ser un número entero.");
                return;
            }

            string nombre = txtNombre.Text;
            string apellido = txtApellido.Text;
            string tipo = cboTipo.SelectedItem.ToString();
            string extra = txtExtra.Text;

            Persona persona;

            if (tipo == "Alumno")
            {
                persona = new Alumno
                {
                    Nombre = nombre,
                    Apellido = apellido,
                    Edad = edad,
                    Carrera = extra
                };
            }
            else
            {
                persona = new Profesor
                {
                    Nombre = nombre,
                    Apellido = apellido,
                    Edad = edad,
                    Materia = extra
                };
            }

            personas.Add(persona);
            ActualizarGrid();
            LimpiarCampos();
        }

        // Método para actualizar el DataGridView
        private void ActualizarGrid()
        {
            dgvPersonas.DataSource = null;
            dgvPersonas.DataSource = personas.Select(p => new
            {
                Tipo = p.GetType().Name,
                Nombre = p.Nombre,
                Apellido = p.Apellido,
                Edad = p.Edad,
                Extra = (p is Alumno a) ? a.Carrera : ((p is Profesor pr) ? pr.Materia : "")
            }).ToList();
        }

        // Método para limpiar los campos después de agregar
        private void LimpiarCampos()
        {
            txtNombre.Clear();
            txtApellido.Clear();
            txtEdad.Clear();
            txtExtra.Clear();
            cboTipo.SelectedIndex = 0;
            lblExtra.Text = "Carrera";
        }
    }
}