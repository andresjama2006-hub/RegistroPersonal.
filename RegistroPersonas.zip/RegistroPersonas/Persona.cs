﻿public abstract class Persona
{
    public string Nombre { get; set; }
    public string Apellido { get; set; }
    public int Edad { get; set; }

    public abstract string MostrarDatos();
}